"""
Vercel API Entry Point for Certificate Generation System
"""
import os
import sys
from flask import Flask, render_template, request, jsonify, send_file

# Add the parent directory to the path so we can import our modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the Vercel-compatible certificate generator
from certificate_generator import VercelCertificateGenerator

# Import mailer functions
try:
    sys.path.append('..')
    from mailer import send_email, send_whatsapp_via_twilio
except ImportError:
    print("⚠️ Mailer functions not available")
    def send_email(*args, **kwargs):
        return False
    def send_whatsapp_via_twilio(*args, **kwargs):
        return False

# Create Flask app
app = Flask(__name__, template_folder='../templates', static_folder='../static')

# Vercel serverless function configuration
app.config['DEBUG'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'vercel-production-key-change-this')

# Initialize certificate generator for Vercel
cert_gen = VercelCertificateGenerator()

# Routes
@app.route('/')
def index():
    """Main page"""
    certificates = cert_gen.list_certificates()
    return render_template('index.html', full_features=True, certificates=certificates)

@app.route('/generate')
def generate_form():
    """Certificate generation form"""
    return render_template('generate.html')

@app.route('/generate_certificate', methods=['POST'])
def generate_certificate():
    """Generate a single certificate"""
    try:
        # Get form data
        recipient_name = request.form.get('recipient_name', '').strip()
        event_name = request.form.get('event_name', '').strip()
        event_date = request.form.get('event_date', '').strip()
        organization = request.form.get('organization', '').strip()
        recipient_email = request.form.get('recipient_email', '').strip()
        recipient_phone = request.form.get('recipient_phone', '').strip()
        
        # Validation
        if not all([recipient_name, event_name, event_date, organization]):
            return jsonify({'success': False, 'error': 'All required fields must be filled'})
        
        # Generate certificate
        result = cert_gen.generate_certificate(
            recipient_name, event_name, event_date, organization,
            recipient_email or None, recipient_phone or None
        )
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'Generation failed: {str(e)}'})

@app.route('/certificates')
def certificates_list():
    """List all certificates"""
    certificates = cert_gen.list_certificates()
    return render_template('certificates_list.html', certificates=certificates)

@app.route('/verify/<certificate_id>')
def verify_certificate(certificate_id):
    """Verify certificate"""
    result = cert_gen.verify_certificate(certificate_id)
    return render_template('verification_result.html', result=result, certificate_id=certificate_id)

@app.route('/bulk_generate')
def bulk_generate_form():
    """Bulk generation form"""
    return render_template('bulk_generate.html')

@app.route('/bulk_send', methods=['POST'])
def bulk_send():
    """Send certificates in bulk"""
    try:
        data = request.get_json()
        certificate_ids = data.get('certificate_ids', [])
        send_method = data.get('method', 'email')
        
        if not certificate_ids:
            return jsonify({'success': False, 'error': 'No certificates selected'})
        
        # For demo purposes, return success
        # In production, implement actual sending logic
        return jsonify({
            'success': True,
            'message': f'Sent {len(certificate_ids)} certificates via {send_method}',
            'sent_count': len(certificate_ids),
            'failed_count': 0
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# Default export for Vercel